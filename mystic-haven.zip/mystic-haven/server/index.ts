import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { handleChat } from "./routes/chat";
import { handleUpload, handleServeFile } from "./routes/upload";
import { listSessions, getSession, deleteSession } from "./routes/history";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);
  app.post("/api/chat", handleChat);
  app.post("/api/upload", handleUpload);
  app.get("/api/uploads/:filename", handleServeFile);

  // History proxy routes -> Flask backend
  app.get("/api/history/sessions", listSessions);
  app.get("/api/history/sessions/:id", getSession);
  app.delete("/api/sessions/:id", deleteSession);

  return app;
}
