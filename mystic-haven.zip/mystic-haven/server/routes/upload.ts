import type { RequestHandler } from "express";
import { IncomingForm } from "formidable";
import fs from "fs";
// import FormData from "form-data"; // Use native FormData

export const handleUpload: RequestHandler = async (req, res) => {
    const form = new IncomingForm();

    form.parse(req, async (err, fields, files) => {
        if (err) {
            console.error("Form parse error", err);
            res.status(500).json({ error: "Upload failed" });
            return;
        }

        const file = files.file?.[0];
        if (!file) {
            res.status(400).json({ error: "No file provided" });
            return;
        }

        try {
            // Forward to Flask backend
            const upstreamUrl = process.env.CHAT_API_URL || "http://127.0.0.1:8080/api/qa_bot";
            let uploadUrl = "http://127.0.0.1:5000/api/upload";
            try {
                const u = new URL(upstreamUrl);
                uploadUrl = `${u.protocol}//${u.host}/api/upload`;
            } catch { }

            const fileBuffer = fs.readFileSync(file.filepath);

            // Use native FormData and Blob (Node 18+)
            const blob = new Blob([fileBuffer], { type: file.mimetype || 'application/octet-stream' });
            const formData = new FormData();
            formData.append("file", blob, file.originalFilename || "upload");

            const resp = await fetch(uploadUrl, {
                method: "POST",
                body: formData,
                // Do NOT set Content-Type header manually for native FormData, fetch handles it
            });

            if (!resp.ok) {
                const text = await resp.text();
                console.error(`Upstream error ${resp.status}: ${text}`);
                throw new Error(`Upstream ${resp.status}`);
            }

            const data = await resp.json();
            res.json(data);

        } catch (error) {
            console.error("Proxy upload error", error);
            res.status(500).json({ error: "Proxy upload failed" });
        }
    });
};

export const handleServeFile: RequestHandler = async (req, res) => {
    const filename = req.params.filename;
    if (!filename) {
        res.status(400).send("No filename");
        return;
    }

    try {
        // Point directly to Flask backend on port 5000
        const targetUrl = "http://127.0.0.1:5000/api/uploads/" + filename;
        console.log(`Proxy: Forwarding to ${targetUrl}`);

        const resp = await fetch(targetUrl);
        if (!resp.ok) {
            console.error(`Proxy: Upstream returned ${resp.status}`);
            res.status(resp.status).send("File not found");
            return;
        }

        // Forward headers like Content-Type
        const contentType = resp.headers.get("Content-Type");
        if (contentType) {
            res.setHeader("Content-Type", contentType);
        }

        // Simple buffer handling for images to avoid "Body is unusable" error
        const arrayBuffer = await resp.arrayBuffer();
        res.send(Buffer.from(arrayBuffer));

    } catch (e) {
        console.error("Proxy serve error", e);
        res.status(500).send("Proxy error");
    }
};

