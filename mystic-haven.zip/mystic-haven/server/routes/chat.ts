import type { RequestHandler } from "express";
import type { ChatRequest as BaseChatRequest, ChatResponse } from "@shared/api";

type ChatRequest = BaseChatRequest & { path_images?: string[] };

/**
 * POST /api/chat
 * Bridges the frontend chat UI to your actual chatbot backend.
 *
 * How it works:
 * - If CHAT_API_URL is set, this route proxies the request to your backend chatbot
 *   (e.g., OpenAI/Rasa/custom API) and returns its JSON response.
 * - If CHAT_API_URL is NOT set, it returns a stubbed reply so you can verify the wiring.
 *
 * Env vars (set in .env or Netlify project settings):
 * - CHAT_API_URL=https://your-bot.example.com/chat
 * - CHAT_API_KEY=xxxx (optional, sent as Authorization: Bearer <key>)
 */
export const handleChat: RequestHandler = async (req, res) => {
  try {
    const body = req.body as ChatRequest;
    if (!body || !Array.isArray(body.messages)) {
      res.status(400).json({ error: "Invalid payload: { messages: ChatTurn[], deepSearch?: boolean } expected" });
      return;
    }

    // const upstreamUrl = process.env.CHAT_API_URL;
    const upstreamUrl = process.env.CHAT_API_URL || "http://127.0.0.1:8080/api/qa_bot";
    const upstreamKey = process.env.CHAT_API_KEY;
    // Extract last user message and a simple session id for the upstream
    const lastUser = [...(body.messages || [])]
      .reverse()
      .find((m) => m.role === "user")?.content ?? "";
    const sessionId = (req.headers["x-session-id"] as string) || `${req.ip ?? "ui"}:${Date.now()}`;

    if (upstreamUrl) {
      const resp = await fetch(upstreamUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(upstreamKey ? { Authorization: `Bearer ${upstreamKey}` } : {}),
        },
        // Map to your qa_bot API contract
        body: JSON.stringify({
          question: lastUser,
          session_id: sessionId,
          path_images: body.path_images || [],
        }),
      });



      if (!resp.ok) {
        const text = await resp.text().catch(() => "");
        res.status(502).json({ error: `Upstream error ${resp.status}`, details: text?.slice(0, 500) });
        return;
      }

      // Parse a variety of possible response shapes from your backend
      let data: any = null;
      try {
        data = await resp.json();
      } catch (e) {
        // fall back to text
        const t = await resp.text().catch(() => "");
        data = t ? { reply: t } : {};
      }

      const reply =
        (typeof data.reply === "string" ? data.reply : undefined) ??
        (typeof data.answer === "string" ? data.answer : undefined) ??
        (typeof data.response === "string" ? data.response : undefined) ??
        (Array.isArray(data) ? (data[0]?.text ?? data[0]?.reply ?? "") : "");

      res.status(200).json({
        reply: reply ?? "",
        sources: data.sources ?? [],
      });
      return;
    }

    // Fallback stub if no upstream configured
    const demo: ChatResponse = {
      reply: body.deepSearch
        ? `Deep search stub response for: "${lastUser}". Replace by setting CHAT_API_URL.`
        : `Stub response for: "${lastUser}". Configure CHAT_API_URL to connect your bot.`,
      sources: [],
    };
    res.status(200).json(demo);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("handleChat error", err);
    res.status(500).json({ error: "Server error" });
  }
};
