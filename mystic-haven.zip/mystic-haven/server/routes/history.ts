import type { RequestHandler } from "express";

function getFlaskBase(): string {
  const upstream = process.env.CHAT_API_URL || "http://127.0.0.1:8080/api/qa_bot";
  try {
    const u = new URL(upstream);
    // Use just the origin (protocol + host + port), Flask serves /api/*
    return `${u.protocol}//${u.host}`;
  } catch {
    return "http://127.0.0.1:8080";
  }
}

const FLASK_BASE = process.env.CHAT_API_BASE || getFlaskBase();

export const listSessions: RequestHandler = async (_req, res) => {
  try {
    const r = await fetch(`${FLASK_BASE}/api/sessions`, { method: "GET" });
    if (!r.ok) {
      const text = await r.text().catch(() => "");
      res.status(502).json({ error: `Upstream error ${r.status}`, details: text?.slice(0, 500) });
      return;
    }
    const data = await r.json();
    res.status(200).json(data);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("listSessions error", err);
    res.status(500).json({ error: "Server error" });
  }
};

export const getSession: RequestHandler = async (req, res) => {
  try {
    const id = req.params.id;
    if (!id) {
      res.status(400).json({ error: "Missing session id" });
      return;
    }
    const r = await fetch(`${FLASK_BASE}/api/sessions/${encodeURIComponent(id)}`, { method: "GET" });
    if (!r.ok) {
      const text = await r.text().catch(() => "");
      res.status(502).json({ error: `Upstream error ${r.status}`, details: text?.slice(0, 500) });
      return;
    }
    const data = await r.json();
    res.status(200).json(data);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("getSession error", err);
    res.status(500).json({ error: "Server error" });
  }
};

export const deleteSession: RequestHandler = async (req, res) => {
  try {
    const id = req.params.id;
    if (!id) {
      res.status(400).json({ error: "Missing session id" });
      return;
    }
    // Point directly to Flask backend on port 5000 to avoid proxy loops
    const targetUrl = `http://127.0.0.1:5000/api/sessions/${encodeURIComponent(id)}`;

    // eslint-disable-next-line no-console
    console.log(`Proxy: Deleting session ${id} at ${targetUrl}`);

    const r = await fetch(targetUrl, { method: "DELETE" });
    if (!r.ok) {
      const text = await r.text().catch(() => "");
      res.status(r.status).json({ error: `Upstream error ${r.status}`, details: text?.slice(0, 500) });
      return;
    }
    const data = await r.json();
    res.status(200).json(data);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("deleteSession error", err);
    res.status(500).json({ error: "Server error" });
  }
};
