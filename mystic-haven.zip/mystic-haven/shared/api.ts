/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

export type ChatRole = "user" | "ai";

export interface ChatTurn {
  role: ChatRole;
  content: string;
}

export interface ChatRequest {
  messages: ChatTurn[];
  deepSearch?: boolean;
}

export interface ChatSource {
  title: string;
  url: string;
}

export interface ChatResponse {
  reply: string;
  sources?: ChatSource[];
  error?: string;
}
