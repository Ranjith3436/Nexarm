Nexarm — Technical Documentation

Overview
--------
Nexarm is a full-stack React + Vite prototype for a Chatbot web & mobile application supporting text and voice chat. It includes an integrated Express server for API endpoints, a responsive frontend built with React Router 6 and TailwindCSS, and a small UI primitives library (shadcn-like components).

Goals
-----
- Provide a maintainable codebase for a chat prototype (web + mobile responsive).
- Demonstrate core UX flows: chat list, active chat, file upload, voice input, deep search toggle, notifications, profile and admin dashboard.
- Ship a production-ready build process and sensible defaults for deployment.

Tech stack
----------
- Frontend: React 18, React Router 6, TypeScript, Vite, TailwindCSS
- Backend: Express (integrated with Vite dev server)
- Testing: Vitest
- UI utilities: Radix primitives, Lucide icons, class-variance-authority, tailwind-merge
- Optional integrations (MCPs): Neon, Netlify, Zapier, Figma, Supabase, Builder.io (CMS), Linear, Notion, Sentry, Context7, Semgrep, Prisma Postgres

Repository structure (key files)
--------------------------------
- client/
  - App.tsx - SPA entry + route registry
  - global.css - Tailwind theming & CSS variables
  - pages/Index.tsx - Home (Chat list + Chat window)
  - pages/Admin.tsx - Admin dashboard mockup
  - pages/Notifications.tsx, pages/Profile.tsx - placeholders
  - components/
    - layout/AppShell.tsx - global layout wrapper
    - layout/TopNav.tsx - top navigation (NavBar)
    - chat/ChatList.tsx - conversations list
    - chat/ChatWindow.tsx - active chat UI (messages, input)
    - chat/ChatBubble.tsx - message bubble component
    - ui/* - shared controls (Button, Input, Avatar, Switch, Toaster)
- server/ - Express route handlers (server/index.ts, server/routes/)
- shared/api.ts - shared types/interfaces
- index.html - HTML shell & meta tags
- package.json - scripts and dependencies

Getting started (local development)
-----------------------------------
Prerequisites: Node.js >= 18, pnpm (preferred) or npm

1) Install dependencies
   pnpm install

2) Development
   pnpm dev
   - Starts Vite dev server. The Express server is integrated for /api routes.

3) Build (production)
   pnpm build
   pnpm start

4) Tests
   pnpm test

Build & production notes
------------------------
- The production build produces a client SPA (vite build) and a server build (vite build --config vite.config.server.ts). The server entry runs dist/server/node-build.mjs.
- package.json specifies "engines.node": ">=18" to set a minimum Node.js runtime.

Environment variables
---------------------
- No sensitive keys are required by default. If you add external services, store secrets in environment variables and don't commit them to git.
- Use the platform environment configuration or DevServerControl tool to set secrets during development.

Coding & architectural conventions
---------------------------------
- Componentization: Break UI into small composable components under client/components. Pages consume these components.
- UI primitives: Button/Input/Avatar live in client/components/ui/. Use cn() utility to merge classes (clsx + tailwind-merge).
- Styling: Tailwind config reads CSS variables in HSL format (global.css sets --* variables). When adding new colors, keep HSL format so Tailwind's theme references (hsl(var(--...))) remain correct.
- Accessibility: Use semantic elements, aria attributes on interactive controls, focus-visible styles provided in button/input components.
- State & data: Lightweight local state for UI. For server data or global caching, use @tanstack/react-query (already present).

Key components (summary)
------------------------
- AppShell: shared header/nav/footer and container layout.
- TopNav (NavBar): brand, navigation, theme toggle (light/dark), mobile menu, external integration links.
- ChatList: searchable conversation list with 'New Chat' CTA.
- ChatWindow: message feed, auto-scrolling, file upload (hidden input), voice input (SpeechRecognition), deep-search toggle.
- ChatBubble: responsive message bubbles with avatar, attachments and typing indicator.
- UI group: Button (cva variants), Input (consistent heights and rounded corners), Switch (Radix), Avatar (Radix fallback).

APIs and server
---------------
- Example endpoints live in server/routes (e.g., GET /api/demo). Add server endpoints for actions that must be proxied or require private keys.
- Keep sensitive logic server side (e.g., calling LLM or external APIs that require keys). Use fetch from client to /api/* endpoints.

Voice & file upload
-------------------
- Voice input uses the browser SpeechRecognition API (webkit prefix fallback). Provide graceful fallback when unsupported.
- File uploads are handled via a hidden input element; integrate with your storage (S3, Neon, Supabase) by posting to a server endpoint.

Testing & quality
-----------------
- Unit & integration: Vitest + React Testing Library (add if needed).
- Lint & formatting: Prettier is included. Add ESLint for stricter linting.
- Security: Run Semgrep or SAST scanning before deployment (Semgrep is available as an MCP integration suggestion below).

Production readiness checklist
------------------------------
- [ ] Add environment variables for external services (secrets)
- [ ] Connect analytics & error monitoring (Sentry)
- [ ] Add CI for typecheck/test/build on PRs
- [ ] Configure deployment (Netlify or Vercel) and set proper env vars
- [ ] Add rate limiting / auth for API endpoints if exposed
- [ ] Add asset pipeline and favicon/logo

Deployment & integrations (MCP suggestions)
-------------------------------------------
You can connect the following Model Context Protocol (MCP) integrations from the Builder.io MCP popover. These are available suggestions for production:

• Neon — serverless Postgres database. Use for persistent conversation storage, session history, and analytics. [Connect to Neon](#open-mcp-popover)
• Netlify — deployment & hosting, continuous deploys. Good for static build + serverless functions. [Connect to Netlify](#open-mcp-popover)
• Zapier — automation across apps (notifications, workflows). [Connect to Zapier](#open-mcp-popover)
• Figma — import designs to Builder.io. Use the Builder Figma plugin for precise visual handoff. (Do not fetch figma.com URLs directly). Get plugin via MCP popover or the Figma community link.
• Supabase — database + auth + storage. Alternative to Neon (good for rapid prototyping). [Connect to Supabase](#open-mcp-popover)
• Builder CMS — content management and page editing inside Builder.io. Useful for marketing pages and content-driven UI. [Connect to Builder.io](#open-mcp-popover)
• Linear — project and issue tracking integration. [Connect to Linear](#open-mcp-popover)
• Notion — documentation sync and knowledge base. [Connect to Notion](#open-mcp-popover)
• Sentry — error monitoring & performance. Connect to capture runtime errors in production. [Connect to Sentry](#open-mcp-popover)
• Context7 — up-to-date docs for frameworks (useful for dev reference). [Connect to Context7](#open-mcp-popover)
• Semgrep — security scanning/SAST. Run before releases to catch vulnerabilities. [Connect to Semgrep](#open-mcp-popover)
• Prisma Postgres — ORM support if you choose Prisma as DB layer. [Connect to Prisma](#open-mcp-popover)

Note: The MCP popover must be opened by you in the UI to connect a provider. Use the [Open MCP popover](#open-mcp-popover) action.

Operational & monitoring recommendations
---------------------------------------
- Add Sentry for runtime error tracking and performance monitoring.
- Centralize logs from your server (stdout) and any serverless functions.
- Add health-check endpoints and simple metrics for uptime.

Style guide & conventions
-------------------------
- Keep components small and focused. Prefer composition over large monolith components.
- Use the cn() helper for conditional classes and tailwind-merge to avoid class collisions.
- When adding new theme tokens, follow HSL var format in global.css so tailwind references remain consistent.

Contributing
------------
- Branch from main for features. Open a PR with description and screenshots.
- Run pnpm test and pnpm typecheck locally before submitting PR.

Next recommended tasks
----------------------
1. Wire persistent storage for conversations (Neon or Supabase).
2. Add authentication (email + social + phone) — Supabase Auth or your preferred provider.
3. Add Sentry for error monitoring and Semgrep for security scanning.
4. Replace placeholder assets with Nexarm brand assets (favicon, logos, avatars).

Questions?
----------
Tell me which areas you want prioritized (auth, DB integration, production deployment) and I’ll generate a focused implementation plan and required code changes.
