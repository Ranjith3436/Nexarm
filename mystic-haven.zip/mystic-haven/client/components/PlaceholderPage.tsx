import AppShell from "@/components/layout/AppShell";
import { Link } from "react-router-dom";

export default function PlaceholderPage({ title, description }: { title: string; description: string }) {
  return (
    <AppShell>
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-2xl font-bold mb-2">{title}</h1>
        <p className="text-muted-foreground mb-4">{description}</p>
        <p className="text-sm">Continue prompting to fill in this page with full designs and interactions.</p>
        <div className="mt-6">
          <Link className="text-primary underline" to="/">Return to Chat</Link>
        </div>
      </div>
    </AppShell>
  );
}
