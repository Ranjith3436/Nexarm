import NavBar from "./TopNav";
import { ReactNode } from "react";

export default function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <NavBar />
      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="container py-4 flex-1 flex flex-col overflow-hidden">{children}</div>
      </main>
      <footer className="border-t flex-none">
        <div className="container py-2 px-8 text-xs text-muted-foreground flex items-center justify-between">
          <p>© {new Date().getFullYear()} Nexarm</p>
          <p className="hidden sm:block">Modern, minimal, and intuitive UI with dark mode.</p>
        </div>
      </footer>
    </div>
  );
}
