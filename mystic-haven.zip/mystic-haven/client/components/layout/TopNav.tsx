import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { MessageCircle, Bell, LayoutDashboard, User2, ExternalLink, Moon, Sun, Menu } from "lucide-react";
import { useEffect, useState } from "react";

function ThemeToggle() {
  const [theme, setTheme] = useState<string>(() =>
    typeof window !== "undefined" ? localStorage.getItem("theme") || "light" : "light",
  );
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    localStorage.setItem("theme", theme);
  }, [theme]);
  return (
    <Button
      variant="ghost"
      size="icon"
      aria-label="Toggle theme"
      onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
    >
      {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
    </Button>
  );
}

function ExternalIntegrations() {
  // Hidden by request: WhatsApp / Telegram / Messenger links
  return null;
}

export default function NavBar() {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b">
      <div className="container flex h-14 items-center justify-between px-3">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center">
              <img src="/Nexarm2.png" alt="Logo" className="h-28 w-auto" />
            </Link>

          </div>
          <nav className="hidden md:flex items-center gap-1">
            <Link to="/" className={cn("nav-link", pathname === "/" && "nav-link-active")}>
              <MessageCircle className="h-4 w-4" /> <span>Chat</span>
            </Link>
            <Link to="/notifications" className={cn("nav-link", pathname.startsWith("/notifications") && "nav-link-active")}>
              <Bell className="h-4 w-4" /> <span>Notifications</span>
            </Link>
            <Link to="/admin" className={cn("nav-link", pathname.startsWith("/admin") && "nav-link-active")}>
              <LayoutDashboard className="h-4 w-4" /> <span>Admin</span>
            </Link>
            <Link to="/profile" className={cn("nav-link", pathname.startsWith("/profile") && "nav-link-active")}>
              <User2 className="h-4 w-4" /> <span>Profile</span>
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <ExternalIntegrations />
          <ThemeToggle />

          <button
            className="inline-flex items-center sm:hidden p-2 rounded-md hover:bg-accent"
            aria-label="Open menu"
            onClick={() => setOpen((s) => !s)}
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t bg-card">
          <div className="container flex flex-col gap-2 p-3">
            <Link to="/" onClick={() => setOpen(false)} className={cn("nav-link", pathname === "/" && "nav-link-active")}>
              <MessageCircle className="h-4 w-4" /> <span>Chat</span>
            </Link>
            <Link to="/notifications" onClick={() => setOpen(false)} className={cn("nav-link", pathname.startsWith("/notifications") && "nav-link-active")}>
              <Bell className="h-4 w-4" /> <span>Notifications</span>
            </Link>
            <Link to="/admin" onClick={() => setOpen(false)} className={cn("nav-link", pathname.startsWith("/admin") && "nav-link-active")}>
              <LayoutDashboard className="h-4 w-4" /> <span>Admin</span>
            </Link>
            <Link to="/profile" onClick={() => setOpen(false)} className={cn("nav-link", pathname.startsWith("/profile") && "nav-link-active")}>
              <User2 className="h-4 w-4" /> <span>Profile</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
