import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

export interface Attachment {
  name: string;
  url?: string;
  type: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "ai";
  text?: string;
  time: string;
  attachments?: Attachment[];
  typing?: boolean;
}

export default function ChatBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === "user";
  return (
    <div className={cn("flex gap-3 items-end", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <Avatar className="h-9 w-9 flex-shrink-0">
          <AvatarFallback>AI</AvatarFallback>
        </Avatar>
      )}
      <div className={cn(
        "rounded-2xl px-4 py-2 shadow-sm border",
        "max-w-full sm:max-w-[80%] md:max-w-[70%]",
        isUser ? "bg-secondary text-secondary-foreground rounded-br-md" : "bg-card text-foreground rounded-bl-md",
      )}>
        {msg.typing ? (
          <div className="flex items-center gap-1 h-5">
            <span className="typing-dot" />
            <span className="typing-dot" />
            <span className="typing-dot" />
          </div>
        ) : (
          <p className="whitespace-pre-wrap leading-relaxed text-sm">{msg.text}</p>
        )}
        {msg.attachments && msg.attachments.length > 0 && (
          <div className="mt-2 grid grid-cols-2 gap-2">
            {msg.attachments.map((att, i) => (
              <div key={i} className="rounded-lg border bg-background text-foreground overflow-hidden">
                {att.type.startsWith("image/") && att.url ? (
                  <img
                    src={att.url}
                    alt={att.name}
                    className="w-full h-auto object-cover max-h-48"
                  />
                ) : (
                  <div className="p-2 text-xs">
                    <p className="font-medium truncate">{att.name}</p>
                    <p className="text-muted-foreground truncate">{att.type}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
        <div className={cn("mt-1 text-[10px] opacity-70", isUser ? "text-secondary-foreground text-right" : "text-muted-foreground text-left")}>{msg.time}</div>
      </div>
      {isUser && (
        <Avatar className="h-9 w-9 flex-shrink-0">
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}
