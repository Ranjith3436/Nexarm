import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Plus, Search, Pencil, Check, X, Trash2 } from "lucide-react";
import { useState } from "react";

export interface ChatSummary {
  id: string;
  title: string;
  lastMessage: string;
  time: string;
}

interface Props {
  items: ChatSummary[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  onRename?: (id: string, title: string) => void;
  onDelete?: (id: string) => void;
}

export default function ChatList({ items, activeId, onSelect, onNewChat, onRename, onDelete }: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  const startEdit = (id: string, current: string) => {
    setEditingId(id);
    setEditValue(current);
  };
  const cancelEdit = () => {
    setEditingId(null);
    setEditValue("");
  };
  const submitEdit = (id: string) => {
    const val = editValue.trim();
    if (val && onRename) onRename(id, val);
    cancelEdit();
  };

  return (
    <div className="rounded-xl border bg-card p-3 h-full flex flex-col overflow-hidden">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center pb-2 border-b">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Search chats" />
        </div>
        <div className="flex-shrink-0">
          <Button className="mt-2 sm:mt-0 w-full sm:w-auto" onClick={onNewChat}>
            <Plus className="h-4 w-4 mr-2" /> New Chat
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto pt-2 space-y-1">
        {items.map((c) => {
          const isActive = activeId === c.id;
          const isEditing = editingId === c.id;
          return (
            <div
              key={c.id}
              className={cn(
                "w-full rounded-lg px-3 py-3 hover:bg-accent transition-colors",
                isActive ? "bg-accent" : "bg-transparent",
              )}
            >
              <div className="flex items-center gap-2">
                <button className="flex-1 text-left min-w-0" onClick={() => onSelect(c.id)}>
                  {isEditing ? (
                    <Input
                      autoFocus
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") submitEdit(c.id);
                        if (e.key === "Escape") cancelEdit();
                      }}
                      className="h-8"
                    />
                  ) : (
                    <p className="font-medium truncate pr-2" title={c.title}>
                      {c.title.length > 30 ? c.title.substring(0, 30) + "..." : c.title}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground truncate mt-1" title={c.lastMessage}>{c.lastMessage}</p>
                </button>
                {isEditing ? (
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" onClick={() => submitEdit(c.id)} title="Save">
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={cancelEdit} title="Cancel">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        startEdit(c.id, c.title);
                      }}
                      title="Rename"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    {onDelete && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm("Are you sure you want to delete this chat?")) {
                            onDelete(c.id);
                          }
                        }}
                        title="Delete"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between mt-1">
                <span className="text-[10px] text-muted-foreground ml-1">{c.time}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
