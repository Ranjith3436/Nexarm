import { useEffect, useRef, useState } from "react";
import ChatBubble, { ChatMessage } from "./ChatBubble";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Mic, MicOff, Paperclip, Send, Search, X } from "lucide-react";

interface Props {
  messages: ChatMessage[];
  onSend: (text: string, files: File[]) => void;
  deepSearch: boolean;
  onToggleDeepSearch: (value: boolean) => void;
}

export default function ChatWindow({ messages, onSend, deepSearch, onToggleDeepSearch }: Props) {
  const [input, setInput] = useState("");
  const [recording, setRecording] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.lastElementChild?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const handleSend = () => {
    const value = input.trim();
    if (!value && selectedFiles.length === 0) return;
    onSend(value, selectedFiles);
    setInput("");
    setSelectedFiles([]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles((prev) => [...prev, ...Array.from(e.target.files!)]);
    }
    // Reset input so same file can be selected again if needed
    if (fileRef.current) fileRef.current.value = "";
  };

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const toggleVoice = async () => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input is not supported in this browser.");
      return;
    }
    if (!recording) {
      const recognition = new SpeechRecognition();
      recognition.lang = "en-US";
      recognition.interimResults = true;
      recognition.onresult = (e: any) => {
        const transcript = Array.from(e.results).map((r) => r[0].transcript).join(" ");
        setInput(transcript);
      };
      recognition.onend = () => setRecording(false);
      // @ts-ignore
      (window as any).__recognition = recognition;
      setRecording(true);
      recognition.start();
    } else {
      // @ts-ignore
      const rec = (window as any).__recognition as SpeechRecognition | undefined;
      try { rec?.stop(); } catch { }
      setRecording(false);
    }
  };

  return (
    <div className="flex flex-col h-full rounded-xl border bg-card overflow-hidden">
      <div className="flex items-center justify-between border-b px-3 py-2">
        <div className="text-sm font-medium">Active Chat</div>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          <Search className="h-4 w-4" />
          <span className="hidden sm:inline">Deep Search</span>
          <Switch checked={deepSearch} onCheckedChange={onToggleDeepSearch as any} />
        </label>
      </div>

      <div ref={listRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-background to-background/60">
        {messages.map((m) => (
          <ChatBubble key={m.id} msg={m} />
        ))}
      </div>

      <div className="border-t p-3 bg-card">
        {/* File Previews */}
        {selectedFiles.length > 0 && (
          <div className="flex gap-2 mb-2 overflow-x-auto pb-2">
            {selectedFiles.map((file, i) => (
              <div key={i} className="relative group flex-shrink-0">
                <div className="h-16 w-16 rounded-md border bg-muted flex items-center justify-center overflow-hidden">
                  {file.type.startsWith("image/") ? (
                    <img
                      src={URL.createObjectURL(file)}
                      alt="preview"
                      className="h-full w-full object-cover"
                      onLoad={(e) => URL.revokeObjectURL((e.target as HTMLImageElement).src)}
                    />
                  ) : (
                    <span className="text-[10px] text-center p-1 break-all">{file.name.slice(0, 8)}...</span>
                  )}
                </div>
                <button
                  onClick={() => removeFile(i)}
                  className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full p-0.5 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => fileRef.current?.click()} aria-label="Upload">
              <Paperclip className="h-5 w-5" />
            </Button>
            <input
              ref={fileRef}
              type="file"
              multiple
              className="hidden"
              onChange={handleFileSelect}
            />
          </div>

          <div className="flex-1">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Type your message..."
            />
          </div>

          <div className="flex items-center gap-2">
            <Button onClick={handleSend} aria-label="Send">
              <Send className="h-4 w-4" />
            </Button>
            <Button variant={recording ? "destructive" : "secondary"} onClick={toggleVoice} aria-label="Voice input">
              {recording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
          </div>
        </div>
        <div className="mt-1 text-[10px] text-muted-foreground">Press Enter to send</div>
      </div>
    </div>
  );
}
