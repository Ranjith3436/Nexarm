import AppShell from "@/components/layout/AppShell";
import ChatList, { ChatSummary } from "@/components/chat/ChatList";
import ChatWindow from "@/components/chat/ChatWindow";
import { ChatMessage } from "@/components/chat/ChatBubble";
import { useEffect, useMemo, useState } from "react";
import type { ChatTurn } from "@shared/api";

function nowTime() {
  const d = new Date();
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

// Local storage for custom session titles
const TITLES_KEY = "nexarm_session_titles";
function loadTitles(): Record<string, string> {
  try {
    const raw = localStorage.getItem(TITLES_KEY);
    return raw ? (JSON.parse(raw) as Record<string, string>) : {};
  } catch {
    return {};
  }
}
function saveTitles(map: Record<string, string>) {
  try {
    localStorage.setItem(TITLES_KEY, JSON.stringify(map));
  } catch { }
}
function setTitleLS(id: string, title: string) {
  const m = loadTitles();
  m[id] = title;
  saveTitles(m);
}
function getTitleLS(id: string): string | undefined {
  return loadTitles()[id];
}
function truncateTitle(s: string, n = 50) {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > n ? `${t.slice(0, n)}…` : t;
}

// Backend response types
interface SessionItem {
  session_id: string;
  message_count: number;
}
interface SessionListResponse {
  sessions: SessionItem[];
  total_count: number;
}
interface SessionHistoryResponse {
  session_id: string;
  history: {
    session_id: string;
    messages: [string, string][]; // [["HumanMessage"|"AIMessage", content], ...]
    exists: boolean;
    error?: string;
  };
  message_count?: number;
  error?: string;
}

type SessionRow = { id: string; count: number; title?: string };

export default function Index() {
  // Sessions from backend + selected session
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  // Messages for the active session
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [deepSearch, setDeepSearch] = useState(false);

  // Helper to map backend history messages to UI messages
  function mapHistoryToMessages(items: [string, string][]): ChatMessage[] {
    return items
      .map(([type, content], idx) => {
        const role = type === "HumanMessage" ? "user" : type === "AIMessage" ? "ai" : null;
        if (!role) return null;

        let text = content;
        const attachments: any[] = [];

        // Regex to find any /tmp/medbot_uploads path in the text
        // captured group 1: the full path
        const pathRegex = /(\/?tmp\/medbot_uploads\/[\w.-]+)/g;

        let match;
        while ((match = pathRegex.exec(content)) !== null) {
          const fullPath = match[1];
          const filename = fullPath.split("/").pop();

          if (filename) {
            const url = `/api/uploads/${filename}`;
            attachments.push({
              name: filename,
              type: "image/jpeg",
              url: url
            });

            // Remove the path from the text, and any "1. " or bullet points before it
            // This is a bit tricky to do cleanly in a loop without messing up indices, 
            // but we can just replace the specific match string.
            text = text.replace(fullPath, "");
          }
        }

        // Clean up any "Medical Images to Analyze:" header or leftover numbering
        text = text.replace(/\*\*Medical Images to Analyze:\*\*\s*/g, "");
        text = text.replace(/^\d+\.\s*$/gm, ""); // Remove empty numbered lines
        text = text.trim();

        return {
          id: `m_${idx}_${Date.now()}`,
          role,
          text,
          time: nowTime(),
          attachments
        } as ChatMessage;
      })
      .filter(Boolean) as ChatMessage[];
  }

  // Fetch session list
  const fetchSessions = async () => {
    try {
      const resp = await fetch("/api/history/sessions");
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = (await resp.json()) as SessionListResponse;
      const list: SessionRow[] = (data.sessions || []).map((s) => ({
        id: s.session_id,
        count: s.message_count,
        title: getTitleLS(s.session_id),
      }));
      setSessions(list);
      // If nothing selected yet but sessions exist, select first
      if (!activeSessionId && list.length > 0) {
        setActiveSessionId(list[0].id);
      }
    } catch {
      // ignore for now
    }
  };

  // Load a particular session's history
  const loadSession = async (id: string) => {
    try {
      const resp = await fetch(`/api/history/sessions/${encodeURIComponent(id)}`);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = (await resp.json()) as SessionHistoryResponse;
      const msgs = mapHistoryToMessages(data.history?.messages || []);
      setMessages(
        msgs.length > 0
          ? msgs
          : [{ id: `m_${Date.now()}_welcome`, role: "ai", text: "Session loaded. How can I help?", time: nowTime() }]
      );

      // Derive default title from first user prompt if not set
      const hasTitle = !!getTitleLS(id);
      if (!hasTitle) {
        const firstUser = (data.history?.messages || []).find(([t]) => t === "HumanMessage");
        if (firstUser && firstUser[1]) {
          const title = truncateTitle(firstUser[1]);
          if (title) {
            setTitleLS(id, title);
            setSessions((arr) => arr.map((s) => (s.id === id ? { ...s, title } : s)));
          }
        }
      }
    } catch {
      setMessages([{ id: `m_${Date.now()}_err`, role: "ai", text: "Failed to load session history.", time: nowTime() }]);
    }
  };

  // Initial load of sessions
  useEffect(() => {
    fetchSessions();
    // Optionally, poll every minute
    const t = setInterval(fetchSessions, 60_000);
    return () => clearInterval(t);
  }, []);

  // When active session changes, load its messages
  useEffect(() => {
    if (activeSessionId) {
      loadSession(activeSessionId);
    }
  }, [activeSessionId]);

  // Build summaries for ChatList from sessions array
  const summaries: ChatSummary[] = useMemo(
    () =>
      sessions.map((s) => {
        const isActive = s.id === activeSessionId;
        // If active, show last message from current messages; else show count
        const last = isActive ? messages[messages.length - 1]?.text || "" : `${s.count} message(s)`;
        const time = isActive ? messages[messages.length - 1]?.time || "" : "";
        const title = s.title || s.id;
        return { id: s.id, title, lastMessage: last, time };
      }),
    [sessions, activeSessionId, messages]
  );

  const ensureActiveSession = () => {
    if (activeSessionId) return activeSessionId;
    const id = `session_${Date.now().toString(36)}`;
    setActiveSessionId(id);
    // Put it in the list immediately (count unknown yet)
    setSessions((arr) => [{ id, count: 0, title: "New chat" }, ...arr]);
    return id;
  };

  const newChat = () => {
    const id = `session_${Date.now().toString(36)}`;
    setActiveSessionId(id);
    setMessages([{ id: `m_${Date.now()}_welcome`, role: "ai", text: "New chat started. How can I help?", time: nowTime() }]);
    setSessions((arr) => [{ id, count: 0, title: "New chat" }, ...arr]);
  };

  const applyFirstPromptAsTitle = (sid: string, firstPrompt: string) => {
    const current = getTitleLS(sid);
    if (!current) {
      const title = truncateTitle(firstPrompt);
      if (title) {
        setTitleLS(sid, title);
        setSessions((arr) => arr.map((s) => (s.id === sid ? { ...s, title } : s)));
      }
    }
  };

  const send = async (text: string, files: File[]) => {
    const sid = ensureActiveSession();

    // Create attachments for UI immediately
    const atts = files.map((f) => ({
      name: f.name,
      type: f.type,
      url: URL.createObjectURL(f)
    }));

    const userMsg: ChatMessage = {
      id: `m_${Date.now()}`,
      role: "user",
      text,
      attachments: atts,
      time: nowTime()
    };
    const typing: ChatMessage = { id: `m_${Date.now()}_t`, role: "ai", typing: true, time: nowTime() };

    // Optimistic UI
    setMessages((arr) => [...arr, userMsg, typing]);

    try {
      // 1. Upload files first if any
      const uploadedPaths: string[] = [];
      if (files.length > 0) {
        for (const file of files) {
          const formData = new FormData();
          formData.append("file", file);
          try {
            const resp = await fetch("/api/upload", {
              method: "POST",
              body: formData,
            });
            if (!resp.ok) throw new Error("Upload failed");
            const data = await resp.json();
            if (data.success && data.file_path) {
              uploadedPaths.push(data.file_path);
            }
          } catch (err) {
            console.error("Failed to upload file:", file.name, err);
            // We continue even if upload fails, or maybe we should stop?
            // For now, let's continue but maybe append an error note to the user message?
          }
        }
      }

      // Build turns from current messages + new user (exclude typing)
      const turns: ChatTurn[] = [...messages, userMsg]
        .filter((m) => !m.typing)
        .map((m) => ({ role: m.role, content: m.text ?? "" }));

      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-session-id": sid,
        },
        body: JSON.stringify({
          messages: turns,
          deepSearch,
          path_images: uploadedPaths // Send newly uploaded paths
        }),
      });

      // If this is the first user prompt for this session, set default title
      applyFirstPromptAsTitle(sid, text);

      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = (await resp.json()) as { reply?: string };

      const aiMsg: ChatMessage = {
        id: `m_${Date.now()}_ai`,
        role: "ai",
        text: data.reply ?? "No reply",
        time: nowTime(),
      };

      setMessages((arr) => arr.filter((m) => !m.typing).concat(aiMsg));
      // Refresh sessions list to update counts
      fetchSessions();
    } catch (_e) {
      const errMsg: ChatMessage = {
        id: `m_${Date.now()}_err`,
        role: "ai",
        text: "Error contacting chatbot backend. Check network/server.",
        time: nowTime(),
      };
      setMessages((arr) => arr.filter((m) => !m.typing).concat(errMsg));
    }
  };

  const [attachmentPaths, setAttachmentPaths] = useState<string[]>([]);

  const upload = async (files: FileList) => {
    const atts = Array.from(files).map((f) => ({ name: f.name, type: f.type }));
    const newPaths: string[] = [];

    // Optimistic UI update
    const userMsg: ChatMessage = {
      id: `m_${Date.now()}_att`,
      role: "user",
      text: `Uploading ${atts.length} file(s)...`,
      attachments: atts,
      time: nowTime(),
    };
    setMessages((arr) => [...arr, userMsg]);

    // Upload each file
    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append("file", file);

      try {
        // Use the same proxy as other API calls (vite proxy -> express -> flask)
        // Since we didn't add a specific proxy route for /api/upload in express, 
        // we might need to add it or rely on a catch-all if one exists.
        // Actually, looking at server/index.ts, we need to add the route there too or 
        // just use the backend URL directly if we were in a unified app, but here we act as client.
        // Let's assume we can hit /api/upload through the proxy if we configure it, 
        // OR we can't because Express doesn't know about it.

        // WAIT: The express server is the backend for the frontend app. 
        // We need to proxy /api/upload in express to the flask backend.
        // CHECK server/index.ts again.

        // For now, let's implement the client side assuming /api/upload works.
        const resp = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        });

        if (!resp.ok) throw new Error("Upload failed");

        const data = await resp.json();
        if (data.success && data.file_path) {
          newPaths.push(data.file_path);
        }
      } catch (err) {
        console.error("Upload error", err);
        // Could update UI to show error
      }
    }

    setAttachmentPaths((prev) => [...prev, ...newPaths]);

    // Update the message to say "Uploaded"
    setMessages((arr) =>
      arr.map(m => m.id === userMsg.id
        ? { ...m, text: `Uploaded ${newPaths.length} file(s). Ready to send.` }
        : m
      )
    );
  };

  const handleRename = (id: string, title: string) => {
    setTitleLS(id, title);
    setSessions((arr) => arr.map((s) => (s.id === id ? { ...s, title } : s)));
  };

  const handleDelete = async (id: string) => {
    try {
      const resp = await fetch(`/api/sessions/${id}`, { method: "DELETE" });
      if (resp.ok) {
        setSessions((arr) => arr.filter((s) => s.id !== id));
        if (activeSessionId === id) {
          setActiveSessionId(null);
          setMessages([]);
        }
      }
    } catch (e) {
      console.error("Failed to delete session", e);
    }
  };

  return (
    <AppShell>
      <div className="grid gap-4 md:grid-cols-12 h-full overflow-hidden">
        <div className="md:col-span-4 h-full overflow-hidden">
          <ChatList
            items={summaries}
            activeId={activeSessionId}
            onSelect={setActiveSessionId}
            onNewChat={newChat}
            onRename={handleRename}
            onDelete={handleDelete}
          />
        </div>
        <div className="md:col-span-8 h-full overflow-hidden">
          <ChatWindow
            messages={messages}
            onSend={send}
            deepSearch={deepSearch}
            onToggleDeepSearch={setDeepSearch}
          />
        </div>
      </div>
    </AppShell>
  );
}
