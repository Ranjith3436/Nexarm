import PlaceholderPage from "@/components/PlaceholderPage";

export default function Notifications() {
  return (
    <PlaceholderPage
      title="Notifications"
      description="Examples of in-app and push notifications for new messages and alerts will be shown here."
    />
  );
}
