import AppShell from "@/components/layout/AppShell";

function StatCard({ label, value, delta }: { label: string; value: string; delta?: string }) {
  return (
    <div className="rounded-xl border p-4 bg-card">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-2 flex items-end justify-between">
        <div className="text-2xl font-semibold">{value}</div>
        {delta && <div className="text-xs text-emerald-600">{delta}</div>}
      </div>
      <svg viewBox="0 0 100 24" className="mt-3 h-10 w-full text-indigo-500">
        <polyline
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          points="0,20 10,18 20,15 30,16 40,10 50,12 60,8 70,9 80,6 90,8 100,5"
        />
      </svg>
    </div>
  );
}

export default function Admin() {
  const users = [
    { id: "u_1", name: "Alex Morgan", status: "online", chats: 14 },
    { id: "u_2", name: "Priya Sharma", status: "idle", chats: 6 },
    { id: "u_3", name: "Kenji Tanaka", status: "offline", chats: 2 },
  ];
  const convos = [
    { id: "c_1", title: "Pricing plan comparison", messages: 23, last: "2m ago" },
    { id: "c_2", title: "Image analysis request", messages: 12, last: "8m ago" },
    { id: "c_3", title: "API integration help", messages: 47, last: "14m ago" },
  ];
  return (
    <AppShell>
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="Active Users" value="1,284" delta="↑ 4.2%" />
        <StatCard label="Conversations Today" value="3,947" delta="↑ 2.1%" />
        <StatCard label="Avg. Response Time" value="1.2s" delta="↓ 0.3s" />
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border bg-card">
          <div className="border-b p-4 font-medium">Recent Users</div>
          <div className="p-4">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr>
                  <th className="font-medium">Name</th>
                  <th className="font-medium">Status</th>
                  <th className="font-medium text-right">Chats</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t">
                    <td className="py-2">{u.name}</td>
                    <td className="py-2 capitalize text-muted-foreground">{u.status}</td>
                    <td className="py-2 text-right">{u.chats}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="rounded-xl border bg-card">
          <div className="border-b p-4 font-medium">Active Conversations</div>
          <div className="p-4 space-y-2">
            {convos.map((c) => (
              <div key={c.id} className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <p className="font-medium">{c.title}</p>
                  <p className="text-xs text-muted-foreground">{c.messages} messages</p>
                </div>
                <span className="text-xs text-muted-foreground">{c.last}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
