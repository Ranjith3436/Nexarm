import PlaceholderPage from "@/components/PlaceholderPage";

export default function Profile() {
  return (
    <PlaceholderPage
      title="User Profile & Login"
      description="Registration/login (email, social, phone) and profile settings will be implemented here."
    />
  );
}
